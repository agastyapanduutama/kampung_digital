<?php 	

// $this->aunt_login->cek_login();

require_once('templates.php');
// require_once('content.php');
// require_once('sidebar.php');